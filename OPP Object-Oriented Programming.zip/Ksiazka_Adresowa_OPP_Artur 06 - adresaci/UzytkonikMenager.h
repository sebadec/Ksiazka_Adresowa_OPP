#ifndef UZYTKONIKMENAGER_H
#define UZYTKONIKMENAGER_H

#include <iostream>
#include <vector>
#include <windows.h>
#include <fstream>
#include <sstream>

#include "Uzytkownik.h"
#include "PlikZUzytkownikami.h"
#include "MetodyPomocnicze.h"

using namespace std;

class UzytkonikMenager{


vector <Uzytkownik> uzytkownicy;

    Uzytkownik podajDaneNowegoUzytkownika();
    int pobierzIdNowegoUzytkownika();
    bool czyIstniejeLogin(string login);
    PlikZUzytkownikami plikZUzytkownikami;
    int idZalogowanegoUzytkownika = 0;

public:
    UzytkonikMenager(string nazwaPlikuZUzytkownikami) : plikZUzytkownikami(nazwaPlikuZUzytkownikami){};
    void rejestracjaUzytkownika();
    void wypiszWszytskichUzytkownikow();
    void wczytajUzytkownikowZPliku();
    void wylogowanieUzytkownikaUM();
    int logowanieUzytkownika();
    void zmianaHaslaZalogowanegoUzytkownikaUM (int idZalogowanegoUzytkownika);
    int pobierzIdZalogowanegoUzytkownika();
    //static int idZalogowanegoUzytkownikaPublic = idZalogowanegoUzytkownika;

};

#endif
